module Main where

main :: IO ()
main = putStrLn "¡Hola, mundo!"

